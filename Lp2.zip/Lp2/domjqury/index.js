$(document).ready(function() {
    // Add a click event handler to the update button
    $('#updateButton').click(function() {
      // Update the text of the message heading
      $('#message').text('Updated message');
    });
  });